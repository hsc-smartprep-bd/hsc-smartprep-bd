/* Reviewed starter question bank. Add questions by editing the matching chapter object. */
const BANK = {
  "chapters": {
    "Physics": {
      "1st Paper": [
        "Physical World and Measurement",
        "Vector",
        "Dynamics",
        "Newtonian Mechanics",
        "Work, Energy and Power",
        "Gravitation and Gravity",
        "Structural Properties of Matter",
        "Periodic Motion",
        "Waves",
        "Ideal Gas and Kinetic Theory"
      ],
      "2nd Paper": [
        "Thermodynamics",
        "Static Electricity",
        "Current Electricity",
        "Magnetic Effects of Current and Magnetism",
        "Electromagnetic Induction and Alternating Current",
        "Geometrical Optics",
        "Physical Optics",
        "Introduction to Modern Physics",
        "Atomic Model and Nuclear Physics",
        "Semiconductor and Electronics",
        "Astronomy"
      ]
    },
    "Chemistry": {
      "1st Paper": [
        "Safe Use of Laboratory",
        "Qualitative Chemistry",
        "Periodic Properties of Elements and Chemical Bonding",
        "Chemical Changes",
        "Applied Chemistry"
      ],
      "2nd Paper": [
        "Environmental Chemistry",
        "Organic Chemistry",
        "Quantitative Chemistry",
        "Electrochemistry",
        "Economic Chemistry"
      ]
    },
    "Biology": {
      "1st Paper": [
        "Cell and Its Structure",
        "Cell Division",
        "Cell Chemistry",
        "Microorganisms",
        "Algae and Fungi",
        "Bryophyta and Pteridophyta",
        "Gymnosperm and Angiosperm",
        "Plant Tissue and Tissue Systems",
        "Plant Physiology",
        "Plant Reproduction",
        "Biotechnology",
        "Environment, Distribution and Conservation of Organisms"
      ],
      "2nd Paper": [
        "Animal Diversity and Classification",
        "Introduction to Animal",
        "Digestion and Absorption",
        "Blood and Circulation",
        "Respiration and Breathing",
        "Excretion",
        "Locomotion",
        "Coordination and Control",
        "Continuity of Human Life",
        "Immunity",
        "Genetics and Evolution",
        "Animal Behaviour"
      ]
    },
    "Higher Math": {
      "1st Paper": [
        "Matrices and Determinants",
        "Vectors",
        "Straight Lines",
        "Circle",
        "Permutations and Combinations",
        "Trigonometric Ratios",
        "Associated Angles",
        "Functions and Graphs",
        "Differentiation",
        "Integration"
      ],
      "2nd Paper": [
        "Real Numbers and Inequalities",
        "Linear Programming",
        "Complex Numbers",
        "Polynomials and Polynomial Equations",
        "Binomial Expansion",
        "Conics",
        "Inverse Trigonometric Functions",
        "Statics",
        "Motion of Particles in a Plane",
        "Probability"
      ]
    },
    "ICT": {
      "Combined": [
        "ICT: World and Bangladesh Perspective",
        "Communication Systems and Networking",
        "Number Systems and Digital Devices",
        "Web Design and HTML",
        "Programming Language",
        "Database Management System"
      ]
    }
  },
  "questions": {
    "Physics": {
      "1st Paper": {
        "Physical World and Measurement": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Physical World and Measurement”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Vector": {
          "mcq": [
            {
              "question": "If two perpendicular vectors have magnitudes 3 and 4, the magnitude of their resultant is:",
              "options": [
                "1",
                "5",
                "7",
                "12"
              ],
              "answer": 1,
              "explanation": "For perpendicular vectors, R = √(3² + 4²) = 5."
            }
          ],
          "cq": [
            "Two forces of 6 N and 8 N act at right angles. Determine the magnitude and direction of their resultant, showing your steps."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Dynamics": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Dynamics”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Newtonian Mechanics": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Newtonian Mechanics”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Work, Energy and Power": {
          "mcq": [
            {
              "question": "The SI unit of work is:",
              "options": [
                "Watt",
                "Joule",
                "Newton",
                "Pascal"
              ],
              "answer": 1,
              "explanation": "Work = force × displacement; its SI unit is the joule (J)."
            }
          ],
          "cq": [
            "A body is lifted vertically through a height h. Explain how its gravitational potential energy changes and calculate the gain for mass m."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Gravitation and Gravity": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Gravitation and Gravity”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Structural Properties of Matter": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Structural Properties of Matter”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Periodic Motion": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Periodic Motion”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Waves": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Waves”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Ideal Gas and Kinetic Theory": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Ideal Gas and Kinetic Theory”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        }
      },
      "2nd Paper": {
        "Thermodynamics": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Thermodynamics”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Static Electricity": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Static Electricity”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Current Electricity": {
          "mcq": [
            {
              "question": "For an ohmic conductor at constant temperature, the V–I graph is:",
              "options": [
                "A circle",
                "A straight line through the origin",
                "A parabola",
                "A horizontal line"
              ],
              "answer": 1,
              "explanation": "Ohm's law gives V = IR, so V is directly proportional to I when R is constant."
            }
          ],
          "cq": [
            "A 6 Ω resistor is connected across a 12 V source. Find the current and power dissipated."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Magnetic Effects of Current and Magnetism": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Magnetic Effects of Current and Magnetism”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Electromagnetic Induction and Alternating Current": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Electromagnetic Induction and Alternating Current”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Geometrical Optics": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Geometrical Optics”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Physical Optics": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Physical Optics”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Introduction to Modern Physics": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Introduction to Modern Physics”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Atomic Model and Nuclear Physics": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Atomic Model and Nuclear Physics”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Semiconductor and Electronics": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Semiconductor and Electronics”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Astronomy": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Astronomy”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        }
      }
    },
    "Chemistry": {
      "1st Paper": {
        "Safe Use of Laboratory": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Safe Use of Laboratory”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Qualitative Chemistry": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Qualitative Chemistry”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Periodic Properties of Elements and Chemical Bonding": {
          "mcq": [
            {
              "question": "Across a period from left to right, atomic radius generally:",
              "options": [
                "Increases",
                "Decreases",
                "Remains constant",
                "Becomes zero"
              ],
              "answer": 1,
              "explanation": "Effective nuclear charge generally increases across a period, pulling electrons closer."
            }
          ],
          "cq": [
            "Explain the general trend in atomic radius across a period and down a group, giving the reasons."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Chemical Changes": {
          "mcq": [
            {
              "question": "A catalyst increases the rate of a reaction mainly by:",
              "options": [
                "Increasing ΔH",
                "Lowering activation energy",
                "Increasing product mass",
                "Changing equilibrium constant"
              ],
              "answer": 1,
              "explanation": "A catalyst provides an alternative pathway with lower activation energy; it does not change the equilibrium constant at a fixed temperature."
            }
          ],
          "cq": [
            "Describe how temperature and a catalyst affect reaction rate. Distinguish their effects on activation energy."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Applied Chemistry": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Applied Chemistry”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        }
      },
      "2nd Paper": {
        "Environmental Chemistry": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Environmental Chemistry”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Organic Chemistry": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Organic Chemistry”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Quantitative Chemistry": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Quantitative Chemistry”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Electrochemistry": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Electrochemistry”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Economic Chemistry": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Economic Chemistry”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        }
      }
    },
    "Biology": {
      "1st Paper": {
        "Cell and Its Structure": {
          "mcq": [
            {
              "question": "Which organelle is the main site of aerobic respiration in eukaryotic cells?",
              "options": [
                "Ribosome",
                "Mitochondrion",
                "Golgi body",
                "Lysosome"
              ],
              "answer": 1,
              "explanation": "Mitochondria host key stages of aerobic respiration and ATP production."
            }
          ],
          "cq": [
            "Compare a plant cell and an animal cell by describing three structural differences and their functions."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Cell Division": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Cell Division”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Cell Chemistry": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Cell Chemistry”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Microorganisms": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Microorganisms”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Algae and Fungi": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Algae and Fungi”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Bryophyta and Pteridophyta": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Bryophyta and Pteridophyta”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Gymnosperm and Angiosperm": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Gymnosperm and Angiosperm”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Plant Tissue and Tissue Systems": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Plant Tissue and Tissue Systems”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Plant Physiology": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Plant Physiology”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Plant Reproduction": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Plant Reproduction”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Biotechnology": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Biotechnology”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Environment, Distribution and Conservation of Organisms": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Environment, Distribution and Conservation of Organisms”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        }
      },
      "2nd Paper": {
        "Animal Diversity and Classification": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Animal Diversity and Classification”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Introduction to Animal": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Introduction to Animal”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Digestion and Absorption": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Digestion and Absorption”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Blood and Circulation": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Blood and Circulation”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Respiration and Breathing": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Respiration and Breathing”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Excretion": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Excretion”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Locomotion": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Locomotion”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Coordination and Control": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Coordination and Control”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Continuity of Human Life": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Continuity of Human Life”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Immunity": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Immunity”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Genetics and Evolution": {
          "mcq": [
            {
              "question": "If T is dominant over t, what fraction of offspring from Tt × Tt is expected to be tt?",
              "options": [
                "0",
                "1/4",
                "1/2",
                "3/4"
              ],
              "answer": 1,
              "explanation": "The genotypes are TT, Tt, Tt and tt; one of four is tt."
            }
          ],
          "cq": [
            "Use a Punnett square to show the expected genotypic ratio from a monohybrid cross Tt × Tt."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Animal Behaviour": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Animal Behaviour”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        }
      }
    },
    "Higher Math": {
      "1st Paper": {
        "Matrices and Determinants": {
          "mcq": [
            {
              "question": "The determinant of [[2, 1], [3, 4]] is:",
              "options": [
                "5",
                "8",
                "11",
                "-5"
              ],
              "answer": 0,
              "explanation": "For a 2×2 matrix, det = ad − bc = (2)(4) − (1)(3) = 5."
            }
          ],
          "cq": [
            "Find the determinant and inverse of the matrix [[2, 1], [3, 4]], showing each step."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Vectors": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Vectors”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Straight Lines": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Straight Lines”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Circle": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Circle”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Permutations and Combinations": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Permutations and Combinations”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Trigonometric Ratios": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Trigonometric Ratios”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Associated Angles": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Associated Angles”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Functions and Graphs": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Functions and Graphs”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Differentiation": {
          "mcq": [
            {
              "question": "If y = x³, then dy/dx is:",
              "options": [
                "x²",
                "2x",
                "3x²",
                "3x"
              ],
              "answer": 2,
              "explanation": "By the power rule, d(xⁿ)/dx = nxⁿ⁻¹, so dy/dx = 3x²."
            }
          ],
          "cq": [
            "Differentiate y = 2x³ − 5x² + 4x − 7 and find the gradient at x = 2."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Integration": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Integration”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        }
      },
      "2nd Paper": {
        "Real Numbers and Inequalities": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Real Numbers and Inequalities”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Linear Programming": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Linear Programming”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Complex Numbers": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Complex Numbers”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Polynomials and Polynomial Equations": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Polynomials and Polynomial Equations”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Binomial Expansion": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Binomial Expansion”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Conics": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Conics”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Inverse Trigonometric Functions": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Inverse Trigonometric Functions”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Statics": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Statics”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Motion of Particles in a Plane": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Motion of Particles in a Plane”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Probability": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Probability”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        }
      }
    },
    "ICT": {
      "Combined": {
        "ICT: World and Bangladesh Perspective": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “ICT: World and Bangladesh Perspective”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Communication Systems and Networking": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Communication Systems and Networking”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Number Systems and Digital Devices": {
          "mcq": [
            {
              "question": "The binary equivalent of decimal 10 is:",
              "options": [
                "1010",
                "1001",
                "1100",
                "1110"
              ],
              "answer": 0,
              "explanation": "10 = 8 + 2, so its binary representation is 1010."
            }
          ],
          "cq": [
            "Convert decimal 25 to binary and explain how positional weights are used in the conversion."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Web Design and HTML": {
          "mcq": [
            {
              "question": "Which HTML element creates a hyperlink?",
              "options": [
                "<p>",
                "<a>",
                "<img>",
                "<h1>"
              ],
              "answer": 1,
              "explanation": "The anchor element <a> creates a hyperlink, usually with an href attribute."
            }
          ],
          "cq": [
            "Write a simple HTML page containing a heading, a paragraph and a link. Explain the role of each element."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Programming Language": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Programming Language”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        },
        "Database Management System": {
          "mcq": [],
          "cq": [
            "Write a structured answer on “Database Management System”: define the key terms, explain the core principle/process, and solve one textbook example relevant to this chapter."
          ],
          "board": [],
          "notes": "Starter content: add reviewed questions from your textbook and authentic board papers here."
        }
      }
    }
  }
};
